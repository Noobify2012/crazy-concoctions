package com.concoctions.model;

import lombok.Data;

@Data
public class Uom {
  long uomId;
  String name;
  String type;
}
