package com.concoctions.model;

import lombok.Data;

@Data
public class Type {
  long typeId;
  String name;
  String description;
}
