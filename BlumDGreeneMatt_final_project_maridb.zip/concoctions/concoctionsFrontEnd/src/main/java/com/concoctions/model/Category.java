package com.concoctions.model;

import lombok.Data;

@Data
public class Category {
  long categoryId;
  String name;
  String description;
}
