package com.concoctions.model;

import lombok.Data;

@Data
public class FoodItem {
  long foodItemId;
  String name;
}
