package com.concoctions.concoctionsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcoctionsBackendApplicationTests {

  @Test
  void contextLoads() {
  }

}
