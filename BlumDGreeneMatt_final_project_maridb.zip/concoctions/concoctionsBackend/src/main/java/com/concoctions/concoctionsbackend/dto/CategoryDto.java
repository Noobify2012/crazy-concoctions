package com.concoctions.concoctionsbackend.dto;

import lombok.Data;

@Data
public class CategoryDto {
  private String name;
  private String description;
}
