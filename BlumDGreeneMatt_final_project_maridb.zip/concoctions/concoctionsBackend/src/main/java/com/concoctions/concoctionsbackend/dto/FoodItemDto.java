package com.concoctions.concoctionsbackend.dto;

import lombok.Data;

@Data
public class FoodItemDto {
  private String name;
}
