package com.concoctions.concoctionsbackend.dto;

import lombok.Data;

@Data
public class TypeDto {
  private String name;
  private String description;


}
