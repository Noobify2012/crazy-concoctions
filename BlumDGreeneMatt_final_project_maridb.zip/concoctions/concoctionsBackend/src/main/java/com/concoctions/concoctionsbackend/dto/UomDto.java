package com.concoctions.concoctionsbackend.dto;

import lombok.Data;

@Data
public class UomDto {
  private String name;
  private String type;
}
